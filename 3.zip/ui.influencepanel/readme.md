# influencepanel
Insert the purpose of this project and some intersting infos here


## Credits
This project has been generated with 💙 and [easy-ui5](https://github.com/SAP)
