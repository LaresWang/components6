sap.ui.define([
  "sap/ui/core/mvc/Controller",
  'sap/ui/model/json/JSONModel',
  "sap/m/RangeSlider"
], function (Controller, JSONModel, Slider) {
  "use strict";

  return Controller.extend("ui.rangeslider.controller.MainView", {
    onInit: function () {
      var oData = {
        rs: [30, 90],

      };

      var oModel = new JSONModel(oData);
      this.getView().setModel(oModel);
    },
    rangeChange: function (a) {
      debugger
      var value = a.getParameters();
      console.log(value.range)
    }
  });
});
